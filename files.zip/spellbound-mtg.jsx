import { useState, useEffect, useRef } from "react";

// ─── PALETTES / CONSTANTS ─────────────────────────────────
const PHASES = ['Untap','Upkeep','Draw','Main 1','Combat','Main 2','End'];
const PHASE_ICONS = ['↩','⏫','🂠','✦','⚔','✦','🌙'];
const PALETTES = [
  {acc:'#a78bfa',glow:'rgba(167,139,250,0.25)',bg:'#0d0a1e',border:'#4c1d95'},
  {acc:'#fb923c',glow:'rgba(251,146,60,0.25)',bg:'#1a0c05',border:'#7c2d12'},
  {acc:'#4ade80',glow:'rgba(74,222,128,0.25)',bg:'#051a0d',border:'#14532d'},
  {acc:'#60a5fa',glow:'rgba(96,165,250,0.25)',bg:'#05101a',border:'#1e3a8a'},
  {acc:'#facc15',glow:'rgba(250,204,21,0.25)',bg:'#1a1505',border:'#713f12'},
  {acc:'#2dd4bf',glow:'rgba(45,212,191,0.25)',bg:'#051a18',border:'#134e4a'},
];
const COUNTER_TYPES = ['+1/+1','-1/-1','Loyalty','Charge','Poison','+2/+2','Oil','Shield','Lore'];

// ─── PRE-EMBEDDED DEMO CARDS ──────────────────────────────
// These are real Scryfall IDs so images load from their CDN.
// Card data is embedded so the game works even if fetch fails.
const DEMO_DATA = [
  {name:'Sol Ring',manaCost:'{1}',cmc:1,typeLine:'Artifact',oracle:'Tap: Add {C}{C}.',power:null,tough:null,rarity:'uncommon',set:'CMR',isLegendary:false,isCreature:false,isPlaneswalker:false,isLand:false,img:'https://cards.scryfall.io/normal/front/0/b/0bd02b38-bc69-4b6e-b1f7-c66b95f61bf5.jpg'},
  {name:'Lightning Bolt',manaCost:'{R}',cmc:1,typeLine:'Instant',oracle:'Lightning Bolt deals 3 damage to any target.',power:null,tough:null,rarity:'common',set:'M11',isLegendary:false,isCreature:false,isPlaneswalker:false,isLand:false,img:'https://cards.scryfall.io/normal/front/e/3/e3285602-4f0f-4998-a5c0-a81e2be8de58.jpg'},
  {name:'Counterspell',manaCost:'{U}{U}',cmc:2,typeLine:'Instant',oracle:'Counter target spell.',power:null,tough:null,rarity:'common',set:'7ED',isLegendary:false,isCreature:false,isPlaneswalker:false,isLand:false,img:'https://cards.scryfall.io/normal/front/8/e/8e2e3abe-4940-4444-ab73-9e3b3f23e88b.jpg'},
  {name:'Dark Ritual',manaCost:'{B}',cmc:1,typeLine:'Instant',oracle:'Add {B}{B}{B}.',power:null,tough:null,rarity:'common',set:'A25',isLegendary:false,isCreature:false,isPlaneswalker:false,isLand:false,img:'https://cards.scryfall.io/normal/front/e/a/ea94a237-94a1-4b63-a52f-9a0d82489a70.jpg'},
  {name:'Giant Growth',manaCost:'{G}',cmc:1,typeLine:'Instant',oracle:'Target creature gets +3/+3 until end of turn.',power:null,tough:null,rarity:'common',set:'M14',isLegendary:false,isCreature:false,isPlaneswalker:false,isLand:false,img:'https://cards.scryfall.io/normal/front/c/6/c69c5e9a-8e31-4e24-a3e5-b61985bf29e5.jpg'},
  {name:'Llanowar Elves',manaCost:'{G}',cmc:1,typeLine:'Creature — Elf Druid',oracle:'Tap: Add {G}.',power:'1',tough:'1',rarity:'common',set:'M19',isLegendary:false,isCreature:true,isPlaneswalker:false,isLand:false,img:'https://cards.scryfall.io/normal/front/3/6/36833fe7-1f4a-4b4f-abb2-8e38be6da1e5.jpg'},
  {name:'Swords to Plowshares',manaCost:'{W}',cmc:1,typeLine:'Instant',oracle:'Exile target creature. Its controller gains life equal to its power.',power:null,tough:null,rarity:'uncommon',set:'A25',isLegendary:false,isCreature:false,isPlaneswalker:false,isLand:false,img:'https://cards.scryfall.io/normal/front/6/f/6fad7162-e1af-4ffc-bf14-f50e76a84e62.jpg'},
  {name:'Brainstorm',manaCost:'{U}',cmc:1,typeLine:'Instant',oracle:'Draw three cards, then put two cards from your hand on top of your library in any order.',power:null,tough:null,rarity:'common',set:'CNS',isLegendary:false,isCreature:false,isPlaneswalker:false,isLand:false,img:'https://cards.scryfall.io/normal/front/f/7/f74a2573-3a49-4826-a1bd-f1df84d38fb9.jpg'},
  {name:'Doom Blade',manaCost:'{1}{B}',cmc:2,typeLine:'Instant',oracle:'Destroy target nonblack creature.',power:null,tough:null,rarity:'common',set:'M14',isLegendary:false,isCreature:false,isPlaneswalker:false,isLand:false,img:'https://cards.scryfall.io/normal/front/8/f/8f7cfc88-a98d-4b65-9a1d-7fb3f75ce0e7.jpg'},
  {name:'Command Tower',manaCost:'',cmc:0,typeLine:'Land',oracle:'Tap: Add one mana of any color in your commander\'s color identity.',power:null,tough:null,rarity:'common',set:'CLB',isLegendary:false,isCreature:false,isPlaneswalker:false,isLand:true,img:'https://cards.scryfall.io/normal/front/4/2/42232ea6-e31d-46a6-9f94-b2ad2416d79b.jpg'},
  {name:'Arcane Signet',manaCost:'{2}',cmc:2,typeLine:'Artifact',oracle:'Tap: Add one mana of any color in your commander\'s color identity.',power:null,tough:null,rarity:'common',set:'CMR',isLegendary:false,isCreature:false,isPlaneswalker:false,isLand:false,img:'https://cards.scryfall.io/normal/front/0/9/09bb1a87-3f40-4d54-9785-0a52a49437cf.jpg'},
  {name:'Mind Stone',manaCost:'{2}',cmc:2,typeLine:'Artifact',oracle:'Tap: Add {C}. {1}, Tap, Sacrifice Mind Stone: Draw a card.',power:null,tough:null,rarity:'uncommon',set:'CMR',isLegendary:false,isCreature:false,isPlaneswalker:false,isLand:false,img:'https://cards.scryfall.io/normal/front/4/3/43ac02c7-67ac-4b9b-9f85-ec1d10461e3a.jpg'},
  {name:'Thought Vessel',manaCost:'{2}',cmc:2,typeLine:'Artifact',oracle:'You have no maximum hand size. Tap: Add {C}.',power:null,tough:null,rarity:'common',set:'CMR',isLegendary:false,isCreature:false,isPlaneswalker:false,isLand:false,img:'https://cards.scryfall.io/normal/front/9/0/90878a14-d2e5-44ba-ba05-56f7e2990a98.jpg'},
  {name:'Swiftfoot Boots',manaCost:'{2}',cmc:2,typeLine:'Artifact — Equipment',oracle:'Equipped creature has hexproof and haste. Equip {1}.',power:null,tough:null,rarity:'uncommon',set:'CMR',isLegendary:false,isCreature:false,isPlaneswalker:false,isLand:false,img:'https://cards.scryfall.io/normal/front/1/f/1f6d1bce-99b1-43c1-b3c9-e6f6e3c4c2d1.jpg'},
  {name:'Lightning Greaves',manaCost:'{2}',cmc:2,typeLine:'Artifact — Equipment',oracle:'Equipped creature has haste and shroud. Equip {0}.',power:null,tough:null,rarity:'uncommon',set:'2XM',isLegendary:false,isCreature:false,isPlaneswalker:false,isLand:false,img:'https://cards.scryfall.io/normal/front/e/9/e9f23edd-56e2-4570-a1de-1f04d05e2afe.jpg'},
  {name:'Reliquary Tower',manaCost:'',cmc:0,typeLine:'Land',oracle:'You have no maximum hand size. Tap: Add {C}.',power:null,tough:null,rarity:'uncommon',set:'CMR',isLegendary:false,isCreature:false,isPlaneswalker:false,isLand:true,img:'https://cards.scryfall.io/normal/front/0/e/0ef4ab62-d9ac-4625-ad18-25babde7aa46.jpg'},
  {name:'Wrath of God',manaCost:'{2}{W}{W}',cmc:4,typeLine:'Sorcery',oracle:'Destroy all creatures. They can\'t be regenerated.',power:null,tough:null,rarity:'rare',set:'A25',isLegendary:false,isCreature:false,isPlaneswalker:false,isLand:false,img:'https://cards.scryfall.io/normal/front/d/b/db10e8bb-2d1e-4b5c-b2ff-acfdbd32ecb0.jpg'},
  {name:'Cyclonic Rift',manaCost:'{1}{U}',cmc:2,typeLine:'Instant',oracle:'Return target nonland permanent you don\'t control to its owner\'s hand. Overload {6}{U}.',power:null,tough:null,rarity:'rare',set:'CMR',isLegendary:false,isCreature:false,isPlaneswalker:false,isLand:false,img:'https://cards.scryfall.io/normal/front/1/b/1b0d6060-fb0e-4dc8-bc0a-f5ef0e9f04da.jpg'},
  {name:'Chaos Warp',manaCost:'{2}{R}',cmc:3,typeLine:'Instant',oracle:'The owner of target permanent shuffles it into their library, then reveals the top card of their library. If it\'s a permanent card, they put it onto the battlefield.',power:null,tough:null,rarity:'rare',set:'CMR',isLegendary:false,isCreature:false,isPlaneswalker:false,isLand:false,img:'https://cards.scryfall.io/normal/front/4/8/48a669b6-ab09-4499-97fa-b9f3b5a9d6ca.jpg'},
  {name:'Blasphemous Act',manaCost:'{8}{R}',cmc:9,typeLine:'Sorcery',oracle:'This spell costs {1} less to cast for each creature on the battlefield. Blasphemous Act deals 13 damage to each creature.',power:null,tough:null,rarity:'rare',set:'CMR',isLegendary:false,isCreature:false,isPlaneswalker:false,isLand:false,img:'https://cards.scryfall.io/normal/front/1/0/10e5a71a-c1bc-4826-a4f0-98a86e7c6c81.jpg'},
  {name:'Murder',manaCost:'{1}{B}{B}',cmc:3,typeLine:'Instant',oracle:'Destroy target creature.',power:null,tough:null,rarity:'common',set:'M21',isLegendary:false,isCreature:false,isPlaneswalker:false,isLand:false,img:'https://cards.scryfall.io/normal/front/0/a/0a9e7dbc-b764-4b37-8ed4-a8f5dab9f6ac.jpg'},
  {name:'Naturalize',manaCost:'{1}{G}',cmc:2,typeLine:'Instant',oracle:'Destroy target artifact or enchantment.',power:null,tough:null,rarity:'common',set:'M14',isLegendary:false,isCreature:false,isPlaneswalker:false,isLand:false,img:'https://cards.scryfall.io/normal/front/6/9/694f01bf-f5ec-4375-a5e3-e29b7e54fe25.jpg'},
  {name:'Negate',manaCost:'{1}{U}',cmc:2,typeLine:'Instant',oracle:'Counter target noncreature spell.',power:null,tough:null,rarity:'common',set:'M20',isLegendary:false,isCreature:false,isPlaneswalker:false,isLand:false,img:'https://cards.scryfall.io/normal/front/8/6/86b1ff45-f7e2-4d18-9d7d-2fb9c1dbc573.jpg'},
  {name:'Swan Song',manaCost:'{U}',cmc:1,typeLine:'Instant',oracle:'Counter target enchantment, instant, or sorcery spell. Its controller creates a 2/2 blue Bird creature token with flying.',power:null,tough:null,rarity:'rare',set:'THS',isLegendary:false,isCreature:false,isPlaneswalker:false,isLand:false,img:'https://cards.scryfall.io/normal/front/b/6/b6f37385-4878-4b6a-8a15-dac872ab0dec.jpg'},
  {name:'Eternal Witness',manaCost:'{1}{G}{G}',cmc:3,typeLine:'Creature — Human Shaman',oracle:'When Eternal Witness enters the battlefield, you may return target card from your graveyard to your hand.',power:'2',tough:'1',rarity:'uncommon',set:'5DN',isLegendary:false,isCreature:true,isPlaneswalker:false,isLand:false,img:'https://cards.scryfall.io/normal/front/e/a/eada5a11-5bb4-4900-a462-93a0ee5e748a.jpg'},
  {name:'Solemn Simulacrum',manaCost:'{4}',cmc:4,typeLine:'Artifact Creature — Golem',oracle:'When Solemn Simulacrum enters the battlefield, you may search your library for a basic land card, put that card onto the battlefield tapped, then shuffle. When Solemn Simulacrum dies, you may draw a card.',power:'2',tough:'2',rarity:'rare',set:'CMR',isLegendary:false,isCreature:true,isPlaneswalker:false,isLand:false,img:'https://cards.scryfall.io/normal/front/9/e/9e64dd5e-7b54-4d58-9c25-43b3ef09e0cb.jpg'},
  {name:'Burnished Hart',manaCost:'{3}',cmc:3,typeLine:'Artifact Creature — Elk',oracle:'{3}, Sacrifice Burnished Hart: Search your library for up to two basic land cards, put them onto the battlefield tapped, then shuffle.',power:'2',tough:'2',rarity:'uncommon',set:'CMR',isLegendary:false,isCreature:true,isPlaneswalker:false,isLand:false,img:'https://cards.scryfall.io/normal/front/0/2/02bc76fb-f372-4c94-b03c-e5c764f28819.jpg'},
  {name:'Mulldrifter',manaCost:'{4}{U}',cmc:5,typeLine:'Creature — Elemental',oracle:'Flying. When Mulldrifter enters the battlefield, draw two cards. Evoke {2}{U}.',power:'2',tough:'2',rarity:'common',set:'CMR',isLegendary:false,isCreature:true,isPlaneswalker:false,isLand:false,img:'https://cards.scryfall.io/normal/front/5/a/5a9c8cfd-acde-45e2-a7c9-78e9da63e60a.jpg'},
  {name:'Thran Dynamo',manaCost:'{4}',cmc:4,typeLine:'Artifact',oracle:'Tap: Add {C}{C}{C}.',power:null,tough:null,rarity:'uncommon',set:'CMR',isLegendary:false,isCreature:false,isPlaneswalker:false,isLand:false,img:'https://cards.scryfall.io/normal/front/c/5/c5d6be47-9d11-4dfe-a456-2ca7a9ce5f52.jpg'},
  {name:'Cultivate',manaCost:'{2}{G}',cmc:3,typeLine:'Sorcery',oracle:'Search your library for up to two basic land cards, reveal those cards, put one onto the battlefield tapped and the other into your hand, then shuffle.',power:null,tough:null,rarity:'common',set:'CMR',isLegendary:false,isCreature:false,isPlaneswalker:false,isLand:false,img:'https://cards.scryfall.io/normal/front/9/9/99f79746-dc4d-4b86-8f48-aa4b69fa04a4.jpg'},
  {name:'Farseek',manaCost:'{1}{G}',cmc:2,typeLine:'Sorcery',oracle:'Search your library for a Plains, Island, Swamp, Mountain, or Forest card, put it onto the battlefield tapped, then shuffle.',power:null,tough:null,rarity:'common',set:'M13',isLegendary:false,isCreature:false,isPlaneswalker:false,isLand:false,img:'https://cards.scryfall.io/normal/front/4/d/4ddce7b8-29dc-40e1-9cd3-00ea6e1de46b.jpg'},
  {name:'Path to Exile',manaCost:'{W}',cmc:1,typeLine:'Instant',oracle:'Exile target creature. Its controller may search their library for a basic land card, put that card onto the battlefield tapped, then shuffle.',power:null,tough:null,rarity:'uncommon',set:'MMA',isLegendary:false,isCreature:false,isPlaneswalker:false,isLand:false,img:'https://cards.scryfall.io/normal/front/5/e/5e4a7b9a-3db7-4c1f-a6da-9c41b71568c0.jpg'},
  {name:'Beast Within',manaCost:'{2}{G}',cmc:3,typeLine:'Instant',oracle:'Destroy target permanent. Its controller creates a 3/3 green Beast creature token.',power:null,tough:null,rarity:'uncommon',set:'CMR',isLegendary:false,isCreature:false,isPlaneswalker:false,isLand:false,img:'https://cards.scryfall.io/normal/front/8/3/83e08546-e643-4916-a53a-4dc0bc204c13.jpg'},
  {name:'Rampant Growth',manaCost:'{1}{G}',cmc:2,typeLine:'Sorcery',oracle:'Search your library for a basic land card, put that card onto the battlefield tapped, then shuffle.',power:null,tough:null,rarity:'common',set:'M12',isLegendary:false,isCreature:false,isPlaneswalker:false,isLand:false,img:'https://cards.scryfall.io/normal/front/a/1/a19caf81-9a38-469b-a5f2-f2f0adcca523.jpg'},
  {name:'Disenchant',manaCost:'{1}{W}',cmc:2,typeLine:'Instant',oracle:'Destroy target artifact or enchantment.',power:null,tough:null,rarity:'common',set:'A25',isLegendary:false,isCreature:false,isPlaneswalker:false,isLand:false,img:'https://cards.scryfall.io/normal/front/e/3/e3f3fc2c-2f95-4d03-8143-2db1b5ab1daa.jpg'},
];

// Build lookup by lowercase name
const DEMO_CACHE = {};
DEMO_DATA.forEach(function(d) { DEMO_CACHE[d.name.toLowerCase()] = d; });

// ─── SCRYFALL FETCH (for custom decks) ────────────────────
const sfCache = {};

async function fetchScryfall(names, onProgress) {
  const unique = [];
  const seen = {};
  names.forEach(function(n) {
    const k = n.trim().toLowerCase();
    if (k && !seen[k] && !(k in sfCache) && !(k in DEMO_CACHE)) {
      seen[k] = true;
      unique.push(n.trim());
    }
  });

  if (unique.length === 0) {
    onProgress && onProgress(names.length, names.length, '');
    return;
  }

  const CHUNK = 75;
  let done = 0;
  for (let i = 0; i < unique.length; i += CHUNK) {
    const chunk = unique.slice(i, i + CHUNK);
    onProgress && onProgress(done, unique.length, chunk[0]);
    try {
      const res = await fetch('https://api.scryfall.com/cards/collection', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({identifiers: chunk.map(function(n){return {name:n};})}),
      });
      if (!res.ok) throw new Error('HTTP ' + res.status);
      const json = await res.json();
      (json.data || []).forEach(function(d) {
        const cf = d.card_faces;
        const mdfc = !!(cf && cf[0] && cf[0].image_uris);
        const card = {
          name: d.name,
          manaCost: d.mana_cost || (cf && cf[0] ? cf[0].mana_cost : '') || '',
          cmc: d.cmc || 0,
          typeLine: d.type_line || '',
          oracle: d.oracle_text || (cf ? cf.map(function(f){return f.oracle_text||'';}).join(' | ') : ''),
          power: d.power || (cf && cf[0] ? cf[0].power : null),
          tough: d.toughness || (cf && cf[0] ? cf[0].toughness : null),
          loyalty: d.loyalty || null,
          rarity: d.rarity || 'common',
          set: (d.set || '???').toUpperCase(),
          isLegendary: (d.type_line||'').indexOf('Legendary') !== -1,
          isCreature: (d.type_line||'').indexOf('Creature') !== -1,
          isPlaneswalker: (d.type_line||'').indexOf('Planeswalker') !== -1,
          isLand: (d.type_line||'').indexOf('Land') !== -1,
          mdfc: mdfc,
          img: (d.image_uris && d.image_uris.normal) || (cf && cf[0] && cf[0].image_uris ? cf[0].image_uris.normal : null),
          imgBack: mdfc ? (cf[1] && cf[1].image_uris ? cf[1].image_uris.normal : null) : null,
          backName: mdfc && cf[1] ? cf[1].name : null,
          backType: mdfc && cf[1] ? cf[1].type_line : null,
          backPower: mdfc && cf[1] ? cf[1].power : null,
          backTough: mdfc && cf[1] ? cf[1].toughness : null,
        };
        sfCache[d.name.toLowerCase()] = card;
        chunk.forEach(function(sn) {
          const slo = sn.toLowerCase();
          if (!(slo in sfCache) && d.name.toLowerCase().indexOf(slo) !== -1) {
            sfCache[slo] = card;
          }
        });
      });
      (json.not_found || []).forEach(function(nf) {
        if (nf.name) sfCache[nf.name.toLowerCase()] = null;
      });
    } catch(err) {
      console.warn('Scryfall fetch failed:', err.message);
      chunk.forEach(function(n) { sfCache[n.toLowerCase()] = null; });
    }
    done += chunk.length;
    if (i + CHUNK < unique.length) await new Promise(function(r){setTimeout(r,110);});
  }
  onProgress && onProgress(done, unique.length, '');
}

function lookupCard(name) {
  const k = name.trim().toLowerCase();
  return DEMO_CACHE[k] || sfCache[k] || null;
}

// ─── DECK PARSER ──────────────────────────────────────────
function parseDeck(text) {
  if (!text || !text.trim()) return [];
  const cards = [];
  let section = 'main';
  text.split('\n').forEach(function(raw) {
    const line = raw.trim();
    if (!line || line[0]==='/' || line[0]==='#') return;
    const lo = line.toLowerCase();
    if (lo==='commander'||lo==='commanders') { section='commander'; return; }
    if (lo==='deck'||lo==='main'||lo==='mainboard') { section='main'; return; }
    if (lo==='sideboard'||lo==='side'||lo==='maybeboard') { section='side'; return; }
    if (section==='side') return;
    const m = line.match(/^(\d+)\s*[xX]?\s+(.+?)(?:\s+\([\w\d-]+\)[\s\d]*)?$/);
    if (m) {
      const qty = parseInt(m[1], 10);
      const name = m[2].trim().split(' // ')[0].trim();
      if (name) for (let q=0;q<qty;q++) cards.push({name:name,section:section});
    }
  });
  return cards;
}

// ─── HELPERS ──────────────────────────────────────────────
function mkInst(data) {
  return Object.assign({}, data, {
    iid: crypto.randomUUID(),
    tapped:false, showBack:false, faceDown:false, summonSick:false,
    counters:{}, x:5+Math.random()*55, y:5+Math.random()*55, z:1,
  });
}
function shuffle(arr) {
  const a=arr.slice();
  for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));const t=a[i];a[i]=a[j];a[j]=t;}
  return a;
}
const rarityCol = function(r){return {common:'#9ca3af',uncommon:'#c0c0c0',rare:'#fbbf24',mythic:'#f97316'}[r]||'#9ca3af';};

// ─── MANA SYMBOLS ─────────────────────────────────────────
const MC = {W:'#f3f0e0',U:'#1a6bb5',B:'#26262a',R:'#d7360f',G:'#186a45',C:'#8b94a0',X:'#9b59b6'};
function ManaSymbols({cost,size}) {
  size=size||13; if(!cost) return null;
  const syms=[]; const re=/\{([^}]+)\}/g; let m;
  while((m=re.exec(cost))!==null) syms.push(m[1]);
  return (
    <span style={{display:'inline-flex',gap:1,flexWrap:'wrap',alignItems:'center'}}>
      {syms.map(function(s,i){
        const isNum=/^\d+$/.test(s);
        const bg=isNum?'#6b7280':(MC[s]||MC[s[0]]||'#6b7280');
        return <span key={i} style={{display:'inline-flex',alignItems:'center',justifyContent:'center',width:size,height:size,borderRadius:'50%',background:bg,border:'1px solid rgba(0,0,0,0.4)',fontSize:size*0.6,fontWeight:800,color:s==='W'?'#1f2937':'#fff',lineHeight:1,minWidth:size}}>{(isNum||s==='X'||s==='Y'||s==='Z')?s:''}</span>;
      })}
    </span>
  );
}

// ─── CARD BACK ────────────────────────────────────────────
function CardBack({w,h}) {
  w=w||'100%'; h=h||'100%';
  return <div style={{width:w,height:h,borderRadius:4,background:'linear-gradient(135deg,#1a237e,#283593)',border:'2px solid #3949ab',display:'flex',alignItems:'center',justifyContent:'center'}}><span style={{fontSize:18,opacity:0.3}}>🂠</span></div>;
}

// ─── CARD TOKEN ───────────────────────────────────────────
function CardToken({card,onMD,onRC,onME,onML}) {
  const img=(card.showBack&&card.imgBack)?card.imgBack:card.img;
  const counters=Object.entries(card.counters||{}).filter(function(e){return e[1]>0;});
  return (
    <div onMouseDown={onMD} onContextMenu={onRC} onMouseEnter={onME} onMouseLeave={onML}
      style={{position:'absolute',left:card.x+'%',top:card.y+'%',width:56,height:78,borderRadius:4,cursor:'grab',zIndex:card.z,transform:'rotate('+(card.tapped?90:0)+'deg)',transition:'transform 0.15s',border:'2px solid '+(card.tapped?'#fbbf24':'rgba(255,255,255,0.15)'),boxShadow:card.tapped?'0 0 8px rgba(251,191,36,0.5)':'0 2px 8px rgba(0,0,0,0.6)',userSelect:'none',overflow:'visible'}}>
      {card.faceDown?<CardBack w={56} h={78}/>:
       img?<img src={img} alt={card.name} draggable={false} style={{width:'100%',height:'100%',borderRadius:3,objectFit:'cover',display:'block'}}/>:
       <div style={{width:'100%',height:'100%',borderRadius:3,background:'linear-gradient(135deg,#1f2937,#111827)',display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',padding:3}}>
         <div style={{fontSize:7,color:'#e2e8f0',fontWeight:700,textAlign:'center',lineHeight:1.2,marginBottom:2}}>{card.name}</div>
         <div style={{fontSize:6,color:'#94a3b8',textAlign:'center'}}>{card.typeLine}</div>
         {card.power!=null&&<div style={{fontSize:8,color:'#fbbf24',marginTop:2,fontWeight:700}}>{card.power}/{card.tough}</div>}
       </div>}
      {counters.length>0&&<div style={{position:'absolute',bottom:-8,left:'50%',transform:'translateX(-50%)',display:'flex',gap:2,zIndex:10}}>
        {counters.map(function(e){const t=e[0],v=e[1];return <span key={t} style={{background:'#111827',border:'1px solid #374151',borderRadius:8,padding:'1px 4px',fontSize:8,fontWeight:700,color:t==='+1/+1'?'#4ade80':t==='-1/-1'?'#f87171':'#fbbf24'}}>{t}×{v}</span>;})}
      </div>}
      {card.summonSick&&card.isCreature&&!card.tapped&&<div style={{position:'absolute',top:-6,right:-6,width:12,height:12,borderRadius:'50%',background:'#ef4444',fontSize:7,display:'flex',alignItems:'center',justifyContent:'center',color:'#fff',zIndex:10}}>💤</div>}
    </div>
  );
}

// ─── CARD ZOOM ────────────────────────────────────────────
function CardZoom({card}) {
  if(!card||card.faceDown) return null;
  const ub=card.showBack&&card.imgBack;
  const img=ub?card.imgBack:card.img;
  const name=ub?(card.backName||card.name):card.name;
  const type=ub?(card.backType||card.typeLine):card.typeLine;
  const pw=ub?card.backPower:card.power;
  const tg=ub?card.backTough:card.tough;
  return (
    <div style={{position:'fixed',right:12,top:'50%',transform:'translateY(-50%)',zIndex:8000,pointerEvents:'none',display:'flex',flexDirection:'column',gap:8}}>
      <div style={{width:180,height:252,borderRadius:8,overflow:'hidden',boxShadow:'0 8px 32px rgba(0,0,0,0.8)',border:'1px solid #374151'}}>
        {img?<img src={img} alt={name} draggable={false} style={{width:'100%',height:'100%',objectFit:'cover'}}/>
            :<div style={{width:'100%',height:'100%',background:'#1f2937',display:'flex',alignItems:'center',justifyContent:'center',padding:12}}><span style={{color:'#e2e8f0',fontSize:12,textAlign:'center',fontWeight:700}}>{name}</span></div>}
      </div>
      <div style={{background:'#111827ee',border:'1px solid #1f2937',borderRadius:6,padding:'8px 10px',width:180}}>
        <div style={{fontSize:12,fontWeight:700,color:'#e2e8f0',marginBottom:2}}>{name}</div>
        <div style={{fontSize:10,color:'#6b7280',marginBottom:5}}>{type}</div>
        {card.manaCost&&<div style={{display:'flex',alignItems:'center',gap:4,marginBottom:4}}><ManaSymbols cost={card.manaCost} size={12}/><span style={{fontSize:9,color:'#4b5563'}}>CMC {card.cmc}</span></div>}
        {card.oracle&&<div style={{fontSize:9,color:'#94a3b8',lineHeight:1.4,maxHeight:80,overflow:'hidden',borderTop:'1px solid #1f2937',paddingTop:4,marginTop:4}}>{card.oracle}</div>}
        <div style={{display:'flex',gap:8,marginTop:6,alignItems:'center'}}>
          {pw!=null&&<span style={{fontSize:12,fontWeight:700,color:'#fbbf24'}}>{pw}/{tg}</span>}
          {card.loyalty!=null&&<span style={{fontSize:12,fontWeight:700,color:'#60a5fa'}}>🛡{card.loyalty}</span>}
          <span style={{fontSize:9,color:rarityCol(card.rarity),marginLeft:'auto'}}>{card.set}</span>
        </div>
        {Object.entries(card.counters||{}).filter(function(e){return e[1]>0;}).length>0&&
          <div style={{marginTop:5,display:'flex',gap:3,flexWrap:'wrap'}}>
            {Object.entries(card.counters).filter(function(e){return e[1]>0;}).map(function(e){const t=e[0],v=e[1];return <span key={t} style={{fontSize:9,background:'#1f2937',borderRadius:4,padding:'1px 5px',color:t==='+1/+1'?'#4ade80':t==='-1/-1'?'#f87171':'#a78bfa',fontWeight:700}}>{t}×{v}</span>;})}
          </div>}
      </div>
    </div>
  );
}

// ─── CONTEXT MENU ─────────────────────────────────────────
function CtxMenu({x,y,card,zone,pal,onAct}) {
  const isBF=zone==='battlefield', isH=zone==='hand', isC=zone==='command';
  const items=[
    isBF?{l:(card&&card.tapped)?'↩ Untap':'↪ Tap',a:'tap',c:'#fbbf24'}:null,
    !isBF?{l:'⚔ Play to Battlefield',a:'toBF',c:'#4ade80'}:null,
    isBF?{l:'✋ Return to Hand',a:'toHand'}:null,
    (isBF||isH)?{l:'💀 Graveyard',a:'toGrave',c:'#f87171'}:null,
    (isBF||isH)?{l:'✦ Exile',a:'toExile',c:'#a78bfa'}:null,
    !isC?{l:'📚 Top of Library',a:'toLib',c:'#60a5fa'}:null,
    (card&&card.mdfc&&isBF)?{l:'🔄 Transform',a:'flip',c:'#60a5fa'}:null,
    (isBF||isH)?{l:'👁 Toggle Face Down',a:'fd'}:null,
    isBF?{l:'🔢 Counters',a:'ctr',c:'#a78bfa'}:null,
    isBF?{l:'📋 Duplicate',a:'dup'}:null,
  ].filter(Boolean);
  const mw=210,mh=items.length*32+52;
  const px=Math.min(x,(window.innerWidth||1200)-mw-8);
  const py=Math.min(y,(window.innerHeight||800)-mh-8);
  return (
    <div onMouseDown={function(e){e.stopPropagation();}} onClick={function(e){e.stopPropagation();}}
      style={{position:'fixed',left:px,top:py,width:mw,background:'#0f172a',border:'1px solid '+pal.border,borderRadius:8,zIndex:9999,overflow:'hidden',boxShadow:'0 8px 32px rgba(0,0,0,0.7)'}}>
      {card&&<div style={{padding:'8px 12px',background:'#0a0f1a',borderBottom:'1px solid #1f2937'}}>
        <div style={{fontSize:12,fontWeight:700,color:pal.acc}}>{card.faceDown?'Face-down Card':card.name}</div>
        {!card.faceDown&&<div style={{fontSize:10,color:'#6b7280',marginTop:1}}>{card.typeLine}</div>}
      </div>}
      {items.map(function(item,i){return (
        <button key={i} onClick={function(){onAct(item.a);}}
          onMouseEnter={function(e){e.currentTarget.style.background='#1f2937';}}
          onMouseLeave={function(e){e.currentTarget.style.background='transparent';}}
          style={{display:'block',width:'100%',textAlign:'left',padding:'7px 14px',background:'transparent',border:'none',borderBottom:i<items.length-1?'1px solid #1f293755':'none',color:item.c||'#d1d5db',fontSize:12,cursor:'pointer'}}>
          {item.l}
        </button>
      );})}
    </div>
  );
}

// ─── ZONE VIEWER ──────────────────────────────────────────
function ZoneViewer({player,zone,onClose,onMove,onHover,onHL,onRC}) {
  const [q,setQ]=useState('');
  const cards=player[zone]||[];
  const shown=q?cards.filter(function(c){return c.name&&c.name.toLowerCase().indexOf(q.toLowerCase())!==-1;}):cards;
  const pal=player.pal;
  const lbl={graveyard:'Graveyard',exile:'Exile',library:'Library',hand:'Hand',command:'Command Zone'};
  return (
    <div style={{position:'fixed',inset:0,background:'rgba(0,0,0,0.75)',zIndex:9000,display:'flex',alignItems:'center',justifyContent:'center'}} onClick={onClose}>
      <div style={{background:'#0f172a',border:'1px solid '+pal.border,borderRadius:10,width:'min(720px,94vw)',maxHeight:'80vh',display:'flex',flexDirection:'column',boxShadow:'0 8px 40px rgba(0,0,0,0.8)'}} onClick={function(e){e.stopPropagation();}}>
        <div style={{padding:'10px 16px',borderBottom:'1px solid '+pal.border+'44',display:'flex',alignItems:'center',gap:12,background:'rgba(0,0,0,0.4)',borderRadius:'10px 10px 0 0'}}>
          <span style={{fontSize:14,fontWeight:700,color:pal.acc}}>{player.name} — {lbl[zone]||zone}</span>
          <span style={{fontSize:12,color:'#6b7280'}}>({cards.length})</span>
          <input value={q} onChange={function(e){setQ(e.target.value);}} placeholder="Search..." style={{marginLeft:'auto',background:'#1f2937',border:'1px solid #374151',borderRadius:4,padding:'3px 8px',color:'#e2e8f0',fontSize:12,outline:'none',width:140}}/>
          <button onClick={onClose} style={{background:'transparent',border:'1px solid #374151',borderRadius:4,color:'#94a3b8',fontSize:12,padding:'3px 8px',cursor:'pointer'}}>✕</button>
        </div>
        <div style={{overflowY:'auto',padding:12,display:'flex',flexWrap:'wrap',gap:10}}>
          {shown.length===0&&<div style={{color:'#4b5563',fontSize:13,textAlign:'center',width:'100%',padding:32}}>{cards.length===0?(lbl[zone]||zone)+' is empty':'No matches'}</div>}
          {shown.map(function(c){return (
            <div key={c.iid} style={{display:'flex',flexDirection:'column',gap:4,alignItems:'center'}}>
              <div style={{width:82,height:115,borderRadius:4,overflow:'hidden',cursor:'pointer',border:'1px solid '+pal.border}} onContextMenu={function(e){e.preventDefault();onRC(e,c);}} onMouseEnter={function(){onHover(c);}} onMouseLeave={onHL}>
                {c.img?<img src={c.img} alt={c.name} draggable={false} style={{width:'100%',height:'100%',objectFit:'cover'}}/>
                      :<div style={{width:'100%',height:'100%',background:'#1f2937',display:'flex',alignItems:'center',justifyContent:'center',fontSize:7,color:'#e2e8f0',textAlign:'center',padding:4,lineHeight:1.3}}>{c.name}</div>}
              </div>
              <div style={{display:'flex',gap:2}}>
                {zone!=='battlefield'&&<button onClick={function(){onMove(c.iid,'battlefield');}} style={{background:'#4ade8022',border:'1px solid #4ade8055',borderRadius:3,color:'#4ade80',fontSize:8,padding:'2px 4px',cursor:'pointer'}}>⚔BF</button>}
                {zone!=='hand'&&<button onClick={function(){onMove(c.iid,'hand');}} style={{background:'#e2e8f022',border:'1px solid #e2e8f055',borderRadius:3,color:'#e2e8f0',fontSize:8,padding:'2px 4px',cursor:'pointer'}}>✋</button>}
                {zone!=='graveyard'&&<button onClick={function(){onMove(c.iid,'graveyard');}} style={{background:'#f8717122',border:'1px solid #f8717155',borderRadius:3,color:'#f87171',fontSize:8,padding:'2px 4px',cursor:'pointer'}}>💀</button>}
                {zone!=='exile'&&<button onClick={function(){onMove(c.iid,'exile');}} style={{background:'#a78bfa22',border:'1px solid #a78bfa55',borderRadius:3,color:'#a78bfa',fontSize:8,padding:'2px 4px',cursor:'pointer'}}>✦</button>}
              </div>
            </div>
          );})}
        </div>
      </div>
    </div>
  );
}

// ─── COUNTER MODAL ────────────────────────────────────────
function CounterModal({card,pal,onAdd,onClose}) {
  if(!card) return null;
  return (
    <div style={{position:'fixed',inset:0,background:'rgba(0,0,0,0.7)',zIndex:9500,display:'flex',alignItems:'center',justifyContent:'center'}} onClick={onClose}>
      <div style={{background:'#0f172a',border:'1px solid '+pal.border,borderRadius:10,padding:20,width:300}} onClick={function(e){e.stopPropagation();}}>
        <div style={{fontSize:14,fontWeight:700,color:pal.acc,marginBottom:14}}>{card.name}</div>
        {COUNTER_TYPES.map(function(type){
          const val=(card.counters&&card.counters[type])||0;
          const col=type==='+1/+1'?'#4ade80':type==='-1/-1'?'#f87171':type==='Loyalty'?'#60a5fa':type==='Poison'?'#a78bfa':'#fbbf24';
          return (
            <div key={type} style={{display:'flex',alignItems:'center',gap:8,marginBottom:8}}>
              <span style={{flex:1,fontSize:12,color:col,fontWeight:600}}>{type}</span>
              <button onClick={function(){onAdd(type,-1);}} style={{background:col+'22',border:'1px solid '+col+'55',borderRadius:4,color:col,fontSize:14,fontWeight:700,padding:'2px 8px',cursor:'pointer'}}>−</button>
              <span style={{fontSize:15,fontWeight:700,color:'#e2e8f0',minWidth:28,textAlign:'center'}}>{val}</span>
              <button onClick={function(){onAdd(type,1);}} style={{background:col+'22',border:'1px solid '+col+'55',borderRadius:4,color:col,fontSize:14,fontWeight:700,padding:'2px 8px',cursor:'pointer'}}>+</button>
            </div>
          );
        })}
        <button onClick={onClose} style={{marginTop:12,width:'100%',padding:'8px 0',background:'#1f2937',border:'1px solid #374151',borderRadius:6,color:'#94a3b8',fontSize:12,cursor:'pointer'}}>Close</button>
      </div>
    </div>
  );
}

// ─── CMD DAMAGE ───────────────────────────────────────────
function CmdDmgModal({player,allPlayers,onDmg,onClose}) {
  const pal=player.pal;
  const others=allPlayers.filter(function(p){return p.pid!==player.pid;});
  return (
    <div style={{position:'fixed',inset:0,background:'rgba(0,0,0,0.7)',zIndex:9500,display:'flex',alignItems:'center',justifyContent:'center'}} onClick={onClose}>
      <div style={{background:'#0f172a',border:'1px solid '+pal.border,borderRadius:10,padding:20,width:340}} onClick={function(e){e.stopPropagation();}}>
        <div style={{fontSize:14,fontWeight:700,color:pal.acc,marginBottom:4}}>{player.name}</div>
        <div style={{fontSize:11,color:'#6b7280',marginBottom:14}}>Commander damage received from:</div>
        {others.map(function(op){
          const dmg=(player.cmdDmg&&player.cmdDmg[op.pid])||0;
          return (
            <div key={op.pid} style={{display:'flex',alignItems:'center',gap:8,padding:'6px 10px',background:'#1f2937',borderRadius:6,marginBottom:6}}>
              <div style={{width:8,height:8,borderRadius:'50%',background:op.pal.acc}}/>
              <span style={{flex:1,fontSize:12,color:op.pal.acc,fontWeight:600}}>{op.name}</span>
              <button onClick={function(){onDmg(op.pid,-1);}} style={{background:'#4ade8022',border:'1px solid #4ade8055',borderRadius:4,color:'#4ade80',fontSize:14,fontWeight:700,padding:'2px 8px',cursor:'pointer'}}>−</button>
              <span style={{fontSize:16,fontWeight:900,minWidth:32,textAlign:'center',color:dmg>=21?'#ef4444':dmg>=10?'#fbbf24':'#e2e8f0'}}>{dmg}</span>
              <button onClick={function(){onDmg(op.pid,1);}} style={{background:'#f8717122',border:'1px solid #f8717155',borderRadius:4,color:'#f87171',fontSize:14,fontWeight:700,padding:'2px 8px',cursor:'pointer'}}>+</button>
              {dmg>=21&&<span style={{fontSize:11,color:'#ef4444',fontWeight:700}}>LETHAL</span>}
            </div>
          );
        })}
        <div style={{fontSize:10,color:'#4b5563',textAlign:'center',marginTop:8}}>21+ commander damage = elimination</div>
        <button onClick={onClose} style={{marginTop:12,width:'100%',padding:'8px 0',background:'#1f2937',border:'1px solid #374151',borderRadius:6,color:'#94a3b8',fontSize:12,cursor:'pointer'}}>Close</button>
      </div>
    </div>
  );
}

// ─── GAME LOG ─────────────────────────────────────────────
function GameLog({entries,onClose}) {
  return (
    <div style={{position:'fixed',left:12,top:'50%',transform:'translateY(-50%)',zIndex:8000,background:'#0f172a',border:'1px solid #1f2937',borderRadius:8,width:270,maxHeight:'60vh',display:'flex',flexDirection:'column',boxShadow:'0 8px 32px rgba(0,0,0,0.8)'}}>
      <div style={{padding:'8px 12px',borderBottom:'1px solid #1f2937',display:'flex',alignItems:'center',gap:8}}>
        <span style={{fontSize:12,fontWeight:700,color:'#fbbf24',flex:1}}>📜 Game Log</span>
        <button onClick={onClose} style={{background:'transparent',border:'none',color:'#6b7280',fontSize:13,cursor:'pointer'}}>✕</button>
      </div>
      <div style={{overflowY:'auto',padding:'6px 12px',flex:1}}>
        {entries.map(function(e,i){return <div key={i} style={{fontSize:10,color:e[0]==='🔄'?'#fbbf24':e[0]==='💀'?'#f87171':'#6b7280',padding:'2px 0',borderBottom:'1px solid #0f172a',lineHeight:1.4}}>{e}</div>;})}
      </div>
    </div>
  );
}

// ─── PLAYER MAT ───────────────────────────────────────────
function PlayerMat({player,isActive,isMain,onDraw,onDeal7,onUntap,onShuffle,onLife,onCardMD,onCardRC,onHover,onHL,onZone,matRef}) {
  const {name,pal,life,poison,library,hand,battlefield,graveyard,exile,command}=player;
  const [handOpen,setHO]=useState(false);
  return (
    <div style={{flex:1,borderRadius:8,position:'relative',overflow:'hidden',display:'flex',flexDirection:'column',background:'radial-gradient(ellipse at center,'+pal.bg+'dd 0%,#0a0a0f 100%)',border:'2px solid '+(isActive?pal.acc:pal.border+'55'),boxShadow:isActive?'0 0 18px '+pal.glow+',inset 0 0 30px '+pal.glow:'none',transition:'box-shadow 0.3s,border-color 0.3s',minHeight:isMain?180:110}}>
      {isActive&&<div style={{position:'absolute',inset:0,background:'radial-gradient(ellipse at center,'+pal.glow+' 0%,transparent 70%)',pointerEvents:'none',zIndex:0}}/>}

      {/* Header */}
      <div style={{display:'flex',alignItems:'center',gap:5,padding:'4px 8px',background:'rgba(0,0,0,0.55)',borderBottom:'1px solid '+pal.border+'33',position:'relative',zIndex:2,flexWrap:'wrap'}}>
        <div style={{width:8,height:8,borderRadius:'50%',background:pal.acc,boxShadow:'0 0 6px '+pal.acc,flexShrink:0}}/>
        <span style={{fontSize:12,fontWeight:700,color:pal.acc,flex:'1 1 auto',minWidth:40}}>{name}{isActive?' ⚡':''}</span>
        <div style={{display:'flex',alignItems:'center',gap:2}}>
          <button onClick={function(){onLife(-1);}} style={{background:'transparent',border:'1px solid #ef444466',borderRadius:3,color:'#ef4444',fontSize:11,fontWeight:700,padding:'1px 5px',cursor:'pointer'}}>−</button>
          <span style={{fontSize:isMain?18:14,fontWeight:900,minWidth:32,textAlign:'center',color:life<=10?'#ef4444':life<=20?'#fbbf24':'#e2e8f0'}}>♥{life}</span>
          <button onClick={function(){onLife(1);}} style={{background:'transparent',border:'1px solid #4ade8066',borderRadius:3,color:'#4ade80',fontSize:11,fontWeight:700,padding:'1px 5px',cursor:'pointer'}}>+</button>
        </div>
        {poison>0&&<span style={{fontSize:11,color:'#a78bfa',fontWeight:700}}>☠{poison}</span>}
        <div style={{display:'flex',gap:3}}>
          {[{z:'library',i:'📚',c:'#60a5fa',n:library.length},{z:'hand',i:'✋',c:'#e2e8f0',n:hand.length},{z:'graveyard',i:'💀',c:'#f87171',n:graveyard.length},{z:'exile',i:'✦',c:'#a78bfa',n:exile.length},{z:'command',i:'👑',c:'#fbbf24',n:command.length}].map(function(z){
            return <button key={z.z} onClick={function(){onZone(z.z);}} style={{background:'transparent',border:'1px solid '+z.c+'44',borderRadius:4,color:z.c,fontSize:9,fontWeight:700,padding:'1px 4px',cursor:'pointer',opacity:z.n===0?0.4:1}}>{z.i}{z.n}</button>;
          })}
        </div>
        <div style={{display:'flex',gap:3}}>
          <button onClick={function(){onDraw();setHO(true);}} style={{background:pal.acc+'15',border:'1px solid '+pal.border,borderRadius:4,color:pal.acc,fontSize:9,fontWeight:600,padding:'2px 5px',cursor:'pointer'}}>Draw 1</button>
          {hand.length===0&&library.length>0&&<button onClick={function(){onDeal7();setHO(true);}} style={{background:'rgba(251,191,36,0.1)',border:'1px solid #fbbf2444',borderRadius:4,color:'#fbbf24',fontSize:9,fontWeight:700,padding:'2px 6px',cursor:'pointer'}}>Deal 7 ★</button>}
          <button onClick={onUntap} style={{background:pal.acc+'15',border:'1px solid '+pal.border,borderRadius:4,color:pal.acc,fontSize:9,fontWeight:600,padding:'2px 5px',cursor:'pointer'}}>Untap</button>
          <button onClick={onShuffle} style={{background:pal.acc+'15',border:'1px solid '+pal.border,borderRadius:4,color:pal.acc,fontSize:9,fontWeight:600,padding:'2px 5px',cursor:'pointer'}}>Shuffle</button>
          <button onClick={function(){setHO(function(o){return !o;});}} style={{background:handOpen?pal.acc+'30':pal.acc+'15',border:'1px solid '+pal.border,borderRadius:4,color:pal.acc,fontSize:9,fontWeight:600,padding:'2px 5px',cursor:'pointer'}}>Hand({hand.length}){handOpen?'▲':'▼'}</button>
        </div>
      </div>

      {/* Battlefield */}
      <div ref={matRef} style={{flex:1,position:'relative',overflow:'hidden',zIndex:1}}>
        {battlefield.map(function(card){return <CardToken key={card.iid} card={card} onMD={function(e){onCardMD(e,card.iid);}} onRC={function(e){onCardRC(e,card.iid,'battlefield');}} onME={function(){onHover(card);}} onML={onHL}/>;  })}
        {battlefield.length===0&&<div style={{position:'absolute',inset:0,display:'flex',alignItems:'center',justifyContent:'center',color:'#1f2937',fontSize:11,pointerEvents:'none'}}>Battlefield — right-click cards in hand to play them here</div>}
      </div>

      {/* Command zone */}
      {command.length>0&&<div style={{position:'absolute',right:4,bottom:handOpen?98:4,display:'flex',flexDirection:'column',gap:2,zIndex:3}}>
        {command.map(function(c){return (
          <div key={c.iid} style={{width:38,height:53,borderRadius:3,overflow:'hidden',cursor:'pointer',border:'2px solid '+pal.acc,boxShadow:'0 0 8px '+pal.glow}} onContextMenu={function(e){onCardRC(e,c.iid,'command');}} onMouseEnter={function(){onHover(c);}} onMouseLeave={onHL}>
            {c.img?<img src={c.img} alt={c.name} draggable={false} style={{width:'100%',height:'100%',objectFit:'cover'}}/>
                  :<div style={{width:'100%',height:'100%',background:'#1f2937',display:'flex',alignItems:'center',justifyContent:'center',fontSize:6,color:'#e2e8f0',textAlign:'center',padding:2}}>{c.name}</div>}
          </div>
        );})}
      </div>}

      {/* Hand tray */}
      {handOpen&&<div style={{position:'relative',zIndex:4,background:'rgba(0,0,0,0.9)',borderTop:'1px solid '+pal.border+'44',padding:6,display:'flex',gap:4,overflowX:'auto',minHeight:90,maxHeight:106}}>
        {hand.length===0
          ?<span style={{color:'#4b5563',fontSize:11,alignSelf:'center',flex:1,textAlign:'center'}}>Hand empty — click Draw 1 or Deal 7 ★</span>
          :hand.map(function(c){return (
            <div key={c.iid} style={{flexShrink:0,width:57,height:80,borderRadius:3,overflow:'hidden',cursor:'pointer',border:'1px solid '+pal.border}} onContextMenu={function(e){onCardRC(e,c.iid,'hand');}} onMouseEnter={function(){onHover(c);}} onMouseLeave={onHL}>
              {c.img?<img src={c.img} alt={c.name} draggable={false} style={{width:'100%',height:'100%',objectFit:'cover'}}/>
                    :<div style={{width:'100%',height:'100%',background:'linear-gradient(135deg,#1f2937,#111827)',display:'flex',alignItems:'center',justifyContent:'center',fontSize:7,color:'#e2e8f0',textAlign:'center',padding:3,lineHeight:1.3,fontWeight:600}}>{c.name}</div>}
            </div>
          );})}
      </div>}
    </div>
  );
}

// ─── TURN BAR ─────────────────────────────────────────────
function TurnBar({players,turn,phase,round,onNext,onPrev,onLog}) {
  const ap=players[turn]; const pal=ap.pal;
  return (
    <div style={{display:'flex',alignItems:'center',gap:8,padding:'5px 12px',background:'rgba(0,0,0,0.9)',borderBottom:'1px solid #1f2937',zIndex:10,flexWrap:'wrap'}}>
      <div style={{fontSize:15,fontWeight:900,color:'#fbbf24',letterSpacing:-1}}>⚔ SPELLBOUND</div>
      <div style={{background:'#1f2937',borderRadius:4,padding:'2px 8px',fontSize:10,color:'#6b7280',fontWeight:600}}>Round {round}</div>
      <div style={{display:'flex',alignItems:'center',gap:6,padding:'3px 10px',background:pal.acc+'18',border:'1px solid '+pal.acc+'44',borderRadius:6}}>
        <div style={{width:8,height:8,borderRadius:'50%',background:pal.acc,boxShadow:'0 0 5px '+pal.acc}}/>
        <span style={{fontSize:12,fontWeight:700,color:pal.acc}}>{ap.name}'s Turn</span>
        <span style={{fontSize:10,color:'#6b7280'}}>♥{ap.life}</span>
      </div>
      <div style={{display:'flex',gap:2,flex:'1 1 auto',justifyContent:'center',flexWrap:'wrap'}}>
        {PHASES.map(function(ph,i){const now=i===phase,past=i<phase;return <div key={ph} style={{padding:'2px 7px',borderRadius:4,fontSize:9,fontWeight:600,background:now?pal.acc:past?'#1f2937':'transparent',color:now?'#000':past?'#4b5563':'#374151',border:'1px solid '+(now?pal.acc:past?'#374151':'#1f2937'),whiteSpace:'nowrap'}}>{PHASE_ICONS[i]} {ph}</div>;  })}
      </div>
      <button onClick={onPrev} style={{background:'#1f2937',border:'1px solid #374151',borderRadius:4,color:'#94a3b8',fontSize:11,padding:'3px 8px',cursor:'pointer'}}>◀</button>
      <button onClick={onNext} style={{background:pal.acc,border:'none',borderRadius:4,color:'#000',fontSize:11,padding:'3px 10px',cursor:'pointer',fontWeight:700}}>Next ▶</button>
      <button onClick={onLog} style={{background:'transparent',border:'1px solid #374151',borderRadius:4,color:'#6b7280',fontSize:11,padding:'3px 6px',cursor:'pointer'}}>📜</button>
    </div>
  );
}

// ─── SETUP SCREEN ─────────────────────────────────────────
function SetupScreen({nPlayers,setNP,setups,setSU,onStart}) {
  return (
    <div style={{minHeight:'100vh',background:'radial-gradient(ellipse at 50% 30%,#0d0a1e 0%,#0a0a0f 100%)',color:'#e2e8f0',display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'flex-start',padding:'32px 16px',overflowY:'auto'}}>
      <div style={{textAlign:'center',marginBottom:36}}>
        <div style={{fontSize:52,fontWeight:900,letterSpacing:-3,background:'linear-gradient(135deg,#fbbf24,#d97706)',WebkitBackgroundClip:'text',WebkitTextFillColor:'transparent'}}>⚔ SPELLBOUND</div>
        <div style={{fontSize:11,color:'#4b5563',letterSpacing:4,marginTop:4}}>MTG COMMANDER ONLINE</div>
        <div style={{fontSize:11,color:'#374151',marginTop:8}}>35 demo cards pre-loaded · Paste Moxfield/MTGO decks for custom play · 2–6 players</div>
      </div>
      <div style={{background:'#111827',border:'1px solid #1f2937',borderRadius:12,padding:24,width:'100%',maxWidth:780}}>
        <div style={{marginBottom:20}}>
          <div style={{fontSize:10,color:'#6b7280',letterSpacing:2,marginBottom:8}}>NUMBER OF PLAYERS</div>
          <div style={{display:'flex',gap:8}}>
            {[2,3,4,5,6].map(function(n){return <button key={n} onClick={function(){setNP(n);}} style={{flex:1,padding:'10px 0',borderRadius:8,cursor:'pointer',border:'2px solid '+(nPlayers===n?'#fbbf24':'#1f2937'),background:nPlayers===n?'rgba(251,191,36,0.1)':'transparent',color:nPlayers===n?'#fbbf24':'#374151',fontSize:20,fontWeight:900}}>{n}</button>;  })}
          </div>
        </div>
        <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(220px,1fr))',gap:12,marginBottom:20}}>
          {setups.slice(0,nPlayers).map(function(p,i){
            const pal=PALETTES[i%PALETTES.length];
            const count=parseDeck(p.deck).length;
            return (
              <div key={i} style={{background:'#0f172a',borderRadius:8,padding:12,border:'1px solid '+pal.acc+'33'}}>
                <div style={{display:'flex',alignItems:'center',gap:6,marginBottom:8}}>
                  <div style={{width:10,height:10,borderRadius:'50%',background:pal.acc,flexShrink:0}}/>
                  <input value={p.name} onChange={function(e){const s=setups.slice();s[i]=Object.assign({},s[i],{name:e.target.value});setSU(s);}} style={{background:'transparent',border:'none',outline:'none',color:pal.acc,fontSize:13,fontWeight:700,flex:1,minWidth:0}} placeholder={'Player '+(i+1)}/>
                </div>
                <textarea value={p.deck} onChange={function(e){const s=setups.slice();s[i]=Object.assign({},s[i],{deck:e.target.value});setSU(s);}}
                  placeholder={"Paste deck:\n1 Sol Ring\n1 Command Tower\n...\nCommander\n1 Atraxa, Praetors' Voice"}
                  style={{width:'100%',height:90,background:'#0a0f1a',border:'1px solid '+pal.border+'44',borderRadius:6,color:'#94a3b8',fontSize:10,padding:8,resize:'vertical',outline:'none',fontFamily:'monospace',boxSizing:'border-box'}}/>
                <div style={{fontSize:10,marginTop:4,color:count>0?pal.acc:'#374151'}}>{count>0?'✓ '+count+' cards detected':'Leave blank → 35 demo cards loaded'}</div>
              </div>
            );
          })}
        </div>
        <button onClick={onStart} style={{width:'100%',padding:'14px 0',borderRadius:8,border:'none',cursor:'pointer',background:'linear-gradient(135deg,#d97706,#b45309)',color:'#fff',fontSize:16,fontWeight:700,letterSpacing:1,boxShadow:'0 0 24px rgba(217,119,6,0.4)'}}>⚔ BEGIN GAME</button>
        <div style={{textAlign:'center',marginTop:10,fontSize:11,color:'#374151'}}>Demo cards always available · Custom deck art via Scryfall · Images © Wizards of the Coast</div>
      </div>
    </div>
  );
}

// ─── LOADING SCREEN ───────────────────────────────────────
function LoadingScreen({done,total,current}) {
  const pct=total>0?Math.round(done/total*100):0;
  return (
    <div style={{minHeight:'100vh',background:'#0a0a0f',display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',color:'#e2e8f0'}}>
      <div style={{fontSize:36,fontWeight:900,color:'#fbbf24',letterSpacing:-2,marginBottom:8}}>⚔ SPELLBOUND</div>
      <div style={{fontSize:11,color:'#4b5563',letterSpacing:3,marginBottom:40}}>LOADING CARD DATA</div>
      <div style={{width:400,maxWidth:'80vw'}}>
        <div style={{background:'#1f2937',borderRadius:8,overflow:'hidden',marginBottom:8,height:10}}>
          <div style={{height:'100%',background:'linear-gradient(90deg,#d97706,#fbbf24)',width:pct+'%',transition:'width 0.3s',borderRadius:8}}/>
        </div>
        <div style={{display:'flex',justifyContent:'space-between',fontSize:11,color:'#4b5563',marginBottom:14}}>
          <span>Fetching via Scryfall...</span><span>{done}/{total} ({pct}%)</span>
        </div>
        {current&&<div style={{textAlign:'center',fontSize:12,color:'#a78bfa',background:'#1f293788',borderRadius:6,padding:'6px 12px'}}>{current}</div>}
      </div>
    </div>
  );
}

// ─── MAIN APP ─────────────────────────────────────────────
export default function App() {
  const [screen,setScreen]=useState('setup');
  const [nPlayers,setNP]=useState(4);
  const [setups,setSU]=useState(Array.from({length:6},function(_,i){return {name:'Player '+(i+1),deck:''};  }));
  const [ld,setLD]=useState({done:0,total:0,current:''});
  const [game,setGame]=useState(null);
  const [hover,setHover]=useState(null);
  const [ctx,setCtx]=useState(null);
  const [zv,setZV]=useState(null);
  const [ctr,setCtr]=useState(null);
  const [dmg,setDmg]=useState(null);
  const [logOpen,setLog]=useState(false);
  const matRefs=useRef({});
  const dragRef=useRef(null);

  useEffect(function(){
    function h(){setCtx(null);}
    window.addEventListener('mousedown',h);
    return function(){window.removeEventListener('mousedown',h);};
  },[]);

  // ── START ─────────────────────────────────────────────
  async function startGame() {
    const active=setups.slice(0,nPlayers);
    setScreen('loading');

    // Collect names that need Scryfall (not in demo cache)
    const customNames=[];
    active.forEach(function(p){
      if(p.deck.trim()){
        parseDeck(p.deck).forEach(function(e){
          if(!DEMO_CACHE[e.name.toLowerCase()]) customNames.push(e.name);
        });
      }
    });

    if(customNames.length>0){
      setLD({done:0,total:customNames.length,current:'Connecting to Scryfall...'});
      await fetchScryfall(customNames,function(done,total,current){
        setLD({done:done,total:Math.max(total,1),current:current||'Processing...'});
      });
    }

    setLD({done:1,total:1,current:'Building game...'});

    const players=active.map(function(pd,idx){
      const isDemo=!pd.deck.trim();
      const entries=isDemo
        ?DEMO_DATA.map(function(d){return {name:d.name,section:'main'};})
        :parseDeck(pd.deck);

      const commanders=[], library=[];
      let missed=0;

      entries.forEach(function(e){
        const cd=lookupCard(e.name);
        if(!cd){missed++;return;}
        const inst=mkInst(cd);
        if(e.section==='commander') commanders.push(inst);
        else library.push(inst);
      });

      // Auto-detect commander
      if(commanders.length===0){
        for(let i=0;i<library.length;i++){
          if(library[i].isLegendary&&(library[i].isCreature||library[i].isPlaneswalker)){
            commanders.push(Object.assign({},library[i]));
            library.splice(i,1);
            break;
          }
        }
      }

      console.log(pd.name+': lib='+library.length+' cmd='+commanders.length+' missed='+missed);

      return {
        pid:idx,name:pd.name,pal:PALETTES[idx%PALETTES.length],
        life:40,poison:0,cmdDmg:{},
        library:shuffle(library),hand:[],battlefield:[],
        graveyard:[],exile:[],command:commanders,
        maxZ:10,isDemo:isDemo,missed:missed,
      };
    });

    const tot=players.reduce(function(s,p){return s+p.library.length+p.command.length;},0);
    const mis=players.reduce(function(s,p){return s+p.missed;},0);

    setGame({
      players:players,turn:0,phase:0,round:1,
      log:[
        '✅ '+tot+' cards ready'+(mis>0?' · '+mis+' not found':'')+' — click "Deal 7 ★" to start!',
        '⚔️ '+players[0].name+' goes first.',
      ],
    });
    setScreen('game');
  }

  // ── MUTATE ────────────────────────────────────────────
  function mut(fn){
    setGame(function(prev){
      const next=Object.assign({},prev,{
        log:prev.log.slice(),
        players:prev.players.map(function(p){
          return Object.assign({},p,{
            library:p.library.slice(),hand:p.hand.slice(),
            battlefield:p.battlefield.slice(),graveyard:p.graveyard.slice(),
            exile:p.exile.slice(),command:p.command.slice(),
            cmdDmg:Object.assign({},p.cmdDmg),
          });
        }),
      });
      fn(next);
      return next;
    });
  }

  // ── ZONE MOVE ─────────────────────────────────────────
  function moveCard(fromPid,iid,toZone,toPid){
    if(toPid===undefined) toPid=fromPid;
    mut(function(g){
      const fp=g.players[fromPid];
      let card=null,fz=null;
      ['hand','battlefield','graveyard','exile','command','library'].forEach(function(z){
        if(card) return;
        const idx=fp[z].findIndex(function(c){return c.iid===iid;});
        if(idx!==-1){card=Object.assign({},fp[z][idx]);fp[z].splice(idx,1);fz=z;}
      });
      if(!card) return;
      card.iid=crypto.randomUUID();
      card.tapped=false;
      card.summonSick=toZone==='battlefield';
      card.z=++g.players[toPid].maxZ;
      if(toZone==='battlefield'){card.x=5+Math.random()*55;card.y=5+Math.random()*55;}
      g.players[toPid][toZone]=g.players[toPid][toZone].concat([card]);
      g.log=[(fp.name+': '+(card.faceDown?'Card':card.name)+' → '+toZone)].concat(g.log.slice(0,99));
    });
    setCtx(null);
  }

  // ── DRAW ──────────────────────────────────────────────
  function drawCards(pid,n){
    n=n||1;
    mut(function(g){
      const p=g.players[pid];
      if(p.library.length===0){g.log=['💀 '+p.name+': library empty!'].concat(g.log.slice(0,99));return;}
      const cnt=Math.min(n,p.library.length);
      const drawn=p.library.splice(0,cnt).map(function(c){return Object.assign({},c,{iid:crypto.randomUUID()});});
      p.hand=p.hand.concat(drawn);
      g.log=[(p.name+' drew '+cnt+' — hand:'+p.hand.length+' lib:'+p.library.length)].concat(g.log.slice(0,99));
    });
  }

  function dealOpening(pid){
    mut(function(g){
      const p=g.players[pid];
      const ret=p.hand.map(function(c){return Object.assign({},c,{iid:crypto.randomUUID()});});
      p.library=shuffle(p.library.concat(ret));
      const cnt=Math.min(7,p.library.length);
      p.hand=p.library.splice(0,cnt).map(function(c){return Object.assign({},c,{iid:crypto.randomUUID()});});
      g.log=['🂠 '+p.name+' drew opening hand ('+cnt+' cards)'].concat(g.log.slice(0,99));
    });
  }

  function untapAll(pid){mut(function(g){g.players[pid].battlefield=g.players[pid].battlefield.map(function(c){return Object.assign({},c,{tapped:false});});g.log=['↩ '+g.players[pid].name+' untapped all'].concat(g.log.slice(0,99));});}
  function shuffleLib(pid){mut(function(g){g.players[pid].library=shuffle(g.players[pid].library);g.log=['🔀 '+g.players[pid].name+' shuffled'].concat(g.log.slice(0,99));});}
  function changeLife(pid,d){mut(function(g){g.players[pid].life=Math.max(-99,g.players[pid].life+d);});}

  function tapCard(pid,iid){
    mut(function(g){g.players[pid].battlefield=g.players[pid].battlefield.map(function(c){return c.iid===iid?Object.assign({},c,{tapped:!c.tapped}):c;});});
    setCtx(null);
  }

  // ── PHASES ────────────────────────────────────────────
  function nextPhase(){
    mut(function(g){
      if(g.phase<PHASES.length-1){
        g.phase++;
        if(PHASES[g.phase]==='Draw'&&g.round>1){
          const p=g.players[g.turn];
          if(p.library.length>0){const c=Object.assign({},p.library[0],{iid:crypto.randomUUID()});p.library=p.library.slice(1);p.hand=p.hand.concat([c]);g.log=[(p.name+' drew for draw step')].concat(g.log.slice(0,99));}
        }
      } else {
        const next=(g.turn+1)%g.players.length;
        if(next===0) g.round++;
        g.turn=next; g.phase=0;
        const np=g.players[next];
        np.battlefield=np.battlefield.map(function(c){return Object.assign({},c,{tapped:false,summonSick:false});});
        g.log=['🔄 '+np.name+"'s turn (Round "+g.round+')'].concat(g.log.slice(0,99));
      }
    });
  }
  function prevPhase(){mut(function(g){if(g.phase>0)g.phase--;});}

  // ── DRAG ──────────────────────────────────────────────
  function onCardMD(e,pid,iid){
    if(e.button!==0) return;
    e.preventDefault();e.stopPropagation();
    if(!game) return;
    const card=game.players[pid].battlefield.find(function(c){return c.iid===iid;});
    if(!card) return;
    mut(function(g){const mz=++g.players[pid].maxZ;g.players[pid].battlefield=g.players[pid].battlefield.map(function(c){return c.iid===iid?Object.assign({},c,{z:mz}):c;});});
    const sx=e.clientX,sy=e.clientY,scx=card.x,scy=card.y;
    dragRef.current=true;
    function onM(ev){
      if(!dragRef.current) return;
      const rect=matRefs.current[pid]&&matRefs.current[pid].getBoundingClientRect();
      if(!rect) return;
      const nx=Math.max(0,Math.min(90,scx+(ev.clientX-sx)/rect.width*100));
      const ny=Math.max(0,Math.min(88,scy+(ev.clientY-sy)/rect.height*100));
      setGame(function(prev){
        return {
          ...prev,
          players: prev.players.map(function(pl,i){
            if(i!==pid) return pl;
            return {
              ...pl,
              battlefield: pl.battlefield.map(function(c){
                return c.iid!==iid ? c : {...c, x:nx, y:ny};
              })
            };
          })
        };
      });
    }
    function onU(){dragRef.current=null;window.removeEventListener('mousemove',onM);window.removeEventListener('mouseup',onU);}
    window.addEventListener('mousemove',onM);
    window.addEventListener('mouseup',onU);
  }

  // ── CTX ACTION ────────────────────────────────────────
  function doCtx(act){
    if(!ctx) return;
    const pid=ctx.pid,iid=ctx.iid;
    if(act==='tap'){tapCard(pid,iid);return;}
    if(act==='toBF'){moveCard(pid,iid,'battlefield');return;}
    if(act==='toHand'){moveCard(pid,iid,'hand');return;}
    if(act==='toGrave'){moveCard(pid,iid,'graveyard');return;}
    if(act==='toExile'){moveCard(pid,iid,'exile');return;}
    if(act==='toLib'){moveCard(pid,iid,'library');return;}
    if(act==='flip'){mut(function(g){g.players[pid].battlefield=g.players[pid].battlefield.map(function(c){return c.iid===iid?Object.assign({},c,{showBack:!c.showBack}):c;});});setCtx(null);return;}
    if(act==='fd'){mut(function(g){['battlefield','hand'].forEach(function(z){g.players[pid][z]=g.players[pid][z].map(function(c){return c.iid===iid?Object.assign({},c,{faceDown:!c.faceDown}):c;});});});setCtx(null);return;}
    if(act==='ctr'){setCtr({pid:pid,iid:iid});setCtx(null);return;}
    if(act==='dup'){mut(function(g){const c=g.players[pid].battlefield.find(function(c){return c.iid===iid;});if(c)g.players[pid].battlefield=g.players[pid].battlefield.concat([Object.assign({},c,{iid:crypto.randomUUID(),x:c.x+4,y:c.y+4,z:++g.players[pid].maxZ})]);});setCtx(null);return;}
    setCtx(null);
  }

  function addCtr(type,delta){
    if(!ctr) return;
    const pid=ctr.pid,iid=ctr.iid;
    mut(function(g){g.players[pid].battlefield=g.players[pid].battlefield.map(function(c){if(c.iid!==iid)return c;const nc=Object.assign({},c.counters);const nv=Math.max(0,(nc[type]||0)+delta);if(nv===0)delete nc[type];else nc[type]=nv;return Object.assign({},c,{counters:nc});});});
  }

  function addCmdDmg(toPid,fromPid,delta){
    mut(function(g){const cur=(g.players[toPid].cmdDmg[fromPid]||0);const nv=Math.max(0,cur+delta);g.players[toPid].cmdDmg[fromPid]=nv;g.players[toPid].life=Math.max(-99,g.players[toPid].life-delta);if(delta!==0)g.log=['⚔ '+g.players[fromPid].name+' → '+g.players[toPid].name+': '+nv+' cmd dmg'].concat(g.log.slice(0,99));});
  }

  function findCard(pid,iid){
    if(!game) return null;
    const zones=['hand','battlefield','graveyard','exile','command','library'];
    for(let i=0;i<zones.length;i++){const c=game.players[pid][zones[i]].find(function(c){return c.iid===iid;});if(c)return c;}
    return null;
  }

  // ── RENDER ────────────────────────────────────────────
  if(screen==='setup') return <SetupScreen nPlayers={nPlayers} setNP={setNP} setups={setups} setSU={setSU} onStart={startGame}/>;
  if(screen==='loading') return <LoadingScreen done={ld.done} total={ld.total} current={ld.current}/>;
  if(!game) return null;

  const {players,turn,phase,round}=game;
  const ctxCard=ctx?findCard(ctx.pid,ctx.iid):null;
  const ctrCard=ctr?players[ctr.pid].battlefield.find(function(c){return c.iid===ctr.iid;}):null;

  return (
    <div onMouseDown={function(){setCtx(null);}} style={{height:'100vh',overflow:'hidden',background:'#0a0a0f',display:'flex',flexDirection:'column',userSelect:'none'}}>
      <TurnBar players={players} turn={turn} phase={phase} round={round} onNext={nextPhase} onPrev={prevPhase} onLog={function(){setLog(function(o){return !o;});}}/>

      <div style={{flex:1,display:'flex',flexDirection:'column',gap:4,padding:4,overflow:'hidden',minHeight:0}}>
        {players.length>1&&(
          <div style={{display:'flex',gap:4,flex:players.length===2?1:0.65,minHeight:0}}>
            {players.slice(1).map(function(p){return (
              <PlayerMat key={p.pid} player={p} isActive={turn===p.pid} isMain={false}
                onDraw={function(){drawCards(p.pid);}} onDeal7={function(){dealOpening(p.pid);}}
                onUntap={function(){untapAll(p.pid);}} onShuffle={function(){shuffleLib(p.pid);}}
                onLife={function(d){changeLife(p.pid,d);}}
                onCardMD={function(e,iid){onCardMD(e,p.pid,iid);}}
                onCardRC={function(e,iid,zone){e.preventDefault();e.stopPropagation();setCtx({x:e.clientX,y:e.clientY,pid:p.pid,iid:iid,zone:zone});}}
                onHover={function(c){setHover(c);}} onHL={function(){setHover(null);}}
                onZone={function(zone){setZV({pid:p.pid,zone:zone});}}
                matRef={function(el){matRefs.current[p.pid]=el;}}/>
            );})}
          </div>
        )}
        <div style={{display:'flex',flex:1,minHeight:0}}>
          <PlayerMat player={players[0]} isActive={turn===0} isMain={true}
            onDraw={function(){drawCards(0);}} onDeal7={function(){dealOpening(0);}}
            onUntap={function(){untapAll(0);}} onShuffle={function(){shuffleLib(0);}}
            onLife={function(d){changeLife(0,d);}}
            onCardMD={function(e,iid){onCardMD(e,0,iid);}}
            onCardRC={function(e,iid,zone){e.preventDefault();e.stopPropagation();setCtx({x:e.clientX,y:e.clientY,pid:0,iid:iid,zone:zone});}}
            onHover={function(c){setHover(c);}} onHL={function(){setHover(null);}}
            onZone={function(zone){setZV({pid:0,zone:zone});}}
            matRef={function(el){matRefs.current[0]=el;}}/>
        </div>
      </div>

      {ctx&&<div onMouseDown={function(e){e.stopPropagation();}}><CtxMenu x={ctx.x} y={ctx.y} card={ctxCard} zone={ctx.zone} pal={players[ctx.pid].pal} onAct={doCtx}/></div>}
      {hover&&<CardZoom card={hover}/>}
      {zv&&<ZoneViewer player={players[zv.pid]} zone={zv.zone} onClose={function(){setZV(null);}} onMove={function(iid,z){moveCard(zv.pid,iid,z);}} onHover={function(c){setHover(c);}} onHL={function(){setHover(null);}} onRC={function(e,c){e.preventDefault();e.stopPropagation();setCtx({x:e.clientX,y:e.clientY,pid:zv.pid,iid:c.iid,zone:zv.zone});}}/>}
      {ctr&&ctrCard&&<CounterModal card={ctrCard} pal={players[ctr.pid].pal} onAdd={addCtr} onClose={function(){setCtr(null);}}/>}
      {dmg!==null&&<CmdDmgModal player={players[dmg]} allPlayers={players} onDmg={function(fp,d){addCmdDmg(dmg,fp,d);}} onClose={function(){setDmg(null);}}/>}
      {logOpen&&<GameLog entries={game.log} onClose={function(){setLog(false);}}/>}

      <div style={{display:'flex',gap:4,padding:'3px 8px',background:'rgba(0,0,0,0.6)',borderTop:'1px solid #1f2937',flexWrap:'wrap'}}>
        {players.map(function(p){return <button key={p.pid} onClick={function(){setDmg(p.pid);}} style={{background:p.pal.acc+'15',border:'1px solid '+p.pal.border,borderRadius:4,color:p.pal.acc,fontSize:9,padding:'2px 7px',cursor:'pointer',fontWeight:600}}>⚔ {p.name.slice(0,8)} cmd</button>;})}
        <button onClick={function(){setScreen('setup');}} style={{background:'transparent',border:'1px solid #1f2937',borderRadius:4,color:'#374151',fontSize:9,padding:'2px 7px',cursor:'pointer',marginLeft:'auto'}}>↩ New Game</button>
      </div>
    </div>
  );
}
